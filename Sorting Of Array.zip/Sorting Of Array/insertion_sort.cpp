#include <iostream>
using namespace std;
int main()
{
    int size;
    cout << "ENTER A SIZE OF ARRAY ::::::::::::::::::";
    cin >> size;
    int array[size];
    cout << "ENTER A VALUES INTO ARRAY :::::::::::::::::::";
    cout << endl;
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    for (int i = 1; i < size; i++)
    {
        int temp = array[i];
        int j = i - 1;
        while (j >= 0 && array[j] > temp)
        {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = temp;
    }
    cout << "Values After sorting  :::::::::::::::::::";
    cout << endl;
    for (int i = 0; i < size; i++)
    {
        cout << array[i] << "      ";
    }
    return 0;
}