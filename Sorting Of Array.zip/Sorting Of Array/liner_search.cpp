#include <iostream>
using namespace std;
int linerSearch(int array[], int size, int key);
int main()
{
    int size;
    cout << "ENTER A SIZE OF ARRAY :::::::::";
    cin >> size;
    int array[size];
    cout << "ENTER A VALUES INT0 ARRAY :::::::::";
    cout << endl;
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    int key;
    cout << "ENTER A KEY YOU WANT TO SEARCH:::::::::::";
    cin >> key;
    cout << linerSearch(array, size, key);
    return 0;
}
int linerSearch(int array[], int size, int key)
{
    int index = -1;
    for (int i = 0; i < size; i++)
    {
        if (key == array[i])
        {
            index = i;
            break;
        }
    }
    return index;
}