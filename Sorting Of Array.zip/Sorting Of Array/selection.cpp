// #include <iostream>
// using namespace std;
// int main()
// {
//     int size;
//     cout << "ENTER A SIZE OF ARRAY:::::::::::::";
//     cin >> size;
//     int array[size];
//     cout << "ENTER A VALUES INTO ARRAY ::::::::::::::::";
//     cout << endl;
//     for (int i = 0; i < size; i++)
//     {
//         cin >> array[i];
//     }
//     for (int i = 0; i < size; i++)
//     {
//         for (int j = i + 1; j < size; j++)
//         {
//             if (array[j] < array[i])
//             {
//                 int temp = array[i];
//                 array[i] = array[j];
//                 array[j] = temp;
//             }
//         }
//     }
//     cout << "VA;IES AFTER SORTING ::::::::::::::::";
//     for (int i = 0; i < size; i++)
//     {
//         cout << "   " << array[i] << "   ";
//     }
//     return 0;
// }
#include <iostream>
using namespace std;
int main()
{
    const int size = 5;
    char arr1[size], arr2[size];
    int check = 0;
    cout << "Enter 1st array :";
    cin >> arr1;
    cout << "\n Enter 2nd array :";
    cin >> arr2;
    for (int index = 0; index < size; index++)
    {
        if (arr1[index] == arr2[index])
        {
            check = 1;
        }
        else
        {
            check = 2;
        }
    }
    if (check == 1)
    {
        cout << "true";
    }
    else
    {
        cout << "false";
    }
    return 0;
}