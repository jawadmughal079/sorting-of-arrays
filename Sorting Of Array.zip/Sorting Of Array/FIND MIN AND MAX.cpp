#include <iostream>
using namespace std;
int main()
{
    int size;
    cout << "ENTER A SIZE OF ARRAY ::::::";
    cin >> size;
    int array[size];
    cout << "ENTER A VALUES INTO ARRAY ::::::::::::::::";
    cout << endl;
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    int min = array[0];
    int max = array[0];
    for (int i = 0; i < size; i++)
    {
        if (min > array[i])
        {
            min = array[i];
        }
        if (max < array[i])
        {
            max = array[i];
        }
    }
    cout << "MIN VALUE OF ARRAY ::::::::" << min;
    cout << endl;
    cout << "MAX VALUE OF ARRAY ::::::::" << max;
    cout << endl;
    return 0;
}